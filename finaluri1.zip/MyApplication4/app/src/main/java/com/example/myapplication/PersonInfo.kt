package com.example.myapplication

data class PersonInfo(
    val firstName: String = "",
    val lastName: String = ""
)
